package com.training.movieapp.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.training.movieapp.model.Movie;

@RestController
public class MovieController {
	
	RestTemplate template = new RestTemplate();
	
	@GetMapping("/")
	public ModelAndView homePage() {
		ModelAndView mav = new ModelAndView("home");
		return mav;
	}
	
	@GetMapping("/show")
	public ModelAndView showMovies() {
		ModelAndView mav = new ModelAndView("movieList");
		
		Object entity = template.getForObject("http://localhost:8080/cinema", Object.class);
		Map<String,Map<String,Object>> movieMap = (Map<String, Map<String,Object>>) entity;
		Map<String,Object> movieList = movieMap.get("_embedded");
		List<Movie> movies = (List<Movie>)movieList.get("movies");
//		for(Map.Entry<Object, Object> entry:movieList.entrySet()) {
//			System.out.println("The Key is "+entry.getKey());
//			System.out.println("The Object is\n"+entry.getValue());
//		}
		mav.addObject("movies",movies);
		
//		System.out.println(movieList);
		
		
//		ResponseEntity<Student[]> entity = template.getForEntity("http://localhost:8085/students", Student[].class);
//		Student[] movieArray = entity.getBody();
//		List<String> movieList = Arrays.stream(movieArray).map(Student::getFirstName).collect(Collectors.toList());
//		for(String s:movieList) {
//			System.out.println(s);
//		}
//		mav.addObject(movieList);
		return mav;
	}
	
	@GetMapping("/addMovie")
	public ModelAndView addMovie() {
		ModelAndView mav = new ModelAndView("addMovie");
		return mav;
	}
	
	@PostMapping("/save")
	public void saveMovie(@ModelAttribute("movie") Movie movie) {
		template.postForLocation("http://localhost:8080/cinema",movie);
	}
	
}
