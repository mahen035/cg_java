package com.training.movies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMoviesApplicationTests {

	@Test
	void contextLoads() {
	}

}
